$(document).ready(function(){
    $( "button" ).click(function() {
      $("img").css({

        "opacity":"0%"
});
      $("body").css({
        
        "background-size":"1300%"});
        $("body").fadeIn();
      setTimeout(function(){
        window.location="../merwan/entree.html"
      }, 600);
      
      
      
        
      
        
        

        
          
        
        });


        
        }); 
        
  
  
